// Content script (ISOLATED world) — bridges postMessage between web app and background SW

// Protocol version — increment when message shapes change in breaking ways.
// The webapp reads this to know which features/messages the extension supports.
var TC_PROTOCOL_VERSION = 1;
var TC_CAPABILITIES = ['llm_streaming', 'fetch_url', 'clip_import', 'clip_import_ack_v2', 'proxy_fetch', 'proxy_fetch_abort', 'notification_ack'];
var tcAppApproved = typeof tcAppApproved === 'boolean' ? tcAppApproved : false;
var tcApprovalRequest = typeof tcApprovalRequest === 'number' ? tcApprovalRequest : 0;

// On file:// pages, window.location.origin is the string "null".
// postMessage(data, "null") silently drops the message. Use '*' instead.
// This is the root cause of the extension not working on standalone (file://) builds.
function postOrigin() {
  return window.location.protocol === 'file:' ? '*' : window.location.origin;
}

// For incoming message origin checks: on file:// both event.origin and
// window.location.origin are "null", so the comparison works. But we still
// need to accept messages from the same window via event.source === window.
function isOwnOrigin(event) {
  if (window.location.protocol === 'file:') return event.source === window;
  return event.origin === window.location.origin;
}

function readyPayload() {
  return {
    type: 'TC_EXTENSION_READY',
    protocolVersion: TC_PROTOCOL_VERSION,
    capabilities: TC_CAPABILITIES,
  };
}
async function refreshAppApproval() {
  var request = ++tcApprovalRequest;
  tcAppApproved = false;
  delete document.documentElement.dataset.tcBridgeCaps;
  try {
    var response = await chrome.runtime.sendMessage({ type: 'PING' });
    if (request !== tcApprovalRequest) return;
    tcAppApproved = response?.loaded === true;
    if (!tcAppApproved) return;
    document.documentElement.dataset.tcBridgeCaps = TC_CAPABILITIES.join(',');
    window.postMessage(readyPayload(), postOrigin());
  } catch {
    if (request === tcApprovalRequest) { tcAppApproved = false; delete document.documentElement.dataset.tcBridgeCaps; }
  }
}

// Guard against duplicate injection (static content_scripts + dynamic executeScript)
if (document.documentElement.dataset.tcBridgeLoaded) {
  // Already loaded — just re-signal readiness and bail out
  if (chrome && chrome.runtime && chrome.runtime.id) {
    refreshAppApproval();
  }
} else {
document.documentElement.dataset.tcBridgeLoaded = '1';

var ports = new Map(); // requestId → Port
var proxyDocumentToken;
var clipProbes = new Map();
var clipDocumentToken;

function isExtensionValid() {
  try {
    return tcAppApproved && !!(chrome && chrome.runtime && chrome.runtime.id);
  } catch {
    return false;
  }
}

// Installed code is not itself permission to bridge an app. Pairing is verified
// independently in the background for every later request and streaming port.
refreshAppApproval();
chrome.storage.onChanged.addListener(function (changes, area) {
  if (area === 'local' && changes.approvedAppsV1) refreshAppApproval();
});

// Re-signal readiness when page is restored from BFCache (back/forward navigation)
document.addEventListener('pageshow', function (event) {
  if (event.persisted && isExtensionValid()) {
    window.postMessage(readyPayload(), postOrigin());
  }
});

// Re-signal when tab becomes visible again (covers additional edge cases)
document.addEventListener('visibilitychange', function () {
  if (!document.hidden && isExtensionValid()) {
    window.postMessage(readyPayload(), postOrigin());
  }
});

// Respond to ping requests from the web app (handles race condition)
window.addEventListener('message', function (event) {
  if (!isOwnOrigin(event)) return;
  if (event.source === window && event.data && event.data.type === 'TC_EXTENSION_PING') {
    if (isExtensionValid()) {
      window.postMessage(readyPayload(), postOrigin());
    }
  }
});

// Listen for LLM requests from the web app
window.addEventListener('message', function (event) {
  if (!isOwnOrigin(event)) return;
  if (event.source !== window) return;
  if (!event.data) return;
  if (!tcAppApproved) return;

  if (event.data.type === 'TC_CLIP_IMPORT_READY') {
    var probe = clipProbes.get(event.data.requestId);
    if (probe && event.data.protocol === 2) probe(event.data);
    return;
  }
  if (event.data.type === 'THREATCADDY_CLIP_IMPORT_RESULT') {
    if (!clipDocumentToken || event.data.protocol !== 2) return;
    // This is a fresh runtime message, not an open sendMessage callback: a late
    // database commit can wake a restarted background worker and persist its ACK.
    chrome.runtime.sendMessage({ type: 'CLIP_IMPORT_RESULT', result: { ...event.data, documentToken: clipDocumentToken } })
      .catch(function () { /* The extension retains unconfirmed captures for retry. */ });
    return;
  }

  if (event.data.type === 'TC_LLM_REQUEST') {
    var requestId = event.data.requestId;
    var payload = event.data.payload;

    if (!isExtensionValid()) {
      window.postMessage({
        type: 'TC_LLM_ERROR',
        requestId: requestId,
        error: chrome.i18n.getMessage('errorExtensionInvalidated')
      }, postOrigin());
      return;
    }

    if (ports.has(requestId)) return; // Never orphan an active connection.
    var port;
    var finished = false;
    function finishLLM() {
      if (finished) return;
      finished = true;
      ports.delete(requestId);
      if (port) {
        port.onMessage.removeListener(receiveLLM);
        port.onDisconnect.removeListener(disconnectLLM);
        try { port.disconnect(); } catch { /* Already disconnected. */ }
      }
    }
    function receiveLLM(msg) {
      if (finished) return;
      if (msg.type === 'chunk') {
        window.postMessage({ type: 'TC_LLM_CHUNK', requestId: requestId, content: msg.content }, postOrigin());
      } else if (msg.type === 'done' || msg.type === 'error') {
        finishLLM();
        window.postMessage(msg.type === 'done'
          ? { type: 'TC_LLM_DONE', requestId: requestId, stopReason: msg.stopReason, contentBlocks: msg.contentBlocks, usage: msg.usage || null }
          : { type: 'TC_LLM_ERROR', requestId: requestId, error: msg.error }, postOrigin());
      }
    }
    function disconnectLLM() {
      if (finished) return;
      var error = chrome.runtime.lastError;
      finishLLM();
      window.postMessage({ type: 'TC_LLM_ERROR', requestId: requestId,
        error: error?.message || chrome.i18n.getMessage('errorExtensionDisconnected') }, postOrigin());
    }
    try {
      port = chrome.runtime.connect({ name: 'llm-' + requestId });
      ports.set(requestId, { finish: finishLLM });
      port.onMessage.addListener(receiveLLM);
      port.onDisconnect.addListener(disconnectLLM);
      port.postMessage(payload);
    } catch (err) {
      finishLLM();
      window.postMessage({
        type: 'TC_LLM_ERROR',
        requestId: requestId,
        error: chrome.i18n.getMessage('errorExtensionUnknown', [err.message || 'unknown'])
      }, postOrigin());
    }
  }

  if (event.data.type === 'TC_FETCH_URL') {
    var fetchRequestId = event.data.requestId;
    var fetchUrl = event.data.url;

    if (!isExtensionValid()) {
      window.postMessage({
        type: 'TC_FETCH_URL_RESULT',
        requestId: fetchRequestId,
        success: false,
        error: chrome.i18n.getMessage('errorExtensionInvalidated')
      }, postOrigin());
      return;
    }

    try {
      chrome.runtime.sendMessage({ type: 'FETCH_URL', url: fetchUrl }, function (response) {
        var lastError = chrome.runtime.lastError;
        if (lastError) {
          window.postMessage({
            type: 'TC_FETCH_URL_RESULT',
            requestId: fetchRequestId,
            success: false,
            error: lastError.message || chrome.i18n.getMessage('errorExtensionError')
          }, postOrigin());
        } else if (!response) {
          window.postMessage({
            type: 'TC_FETCH_URL_RESULT',
            requestId: fetchRequestId,
            success: false,
            error: chrome.i18n.getMessage('errorNoResponse')
          }, postOrigin());
        } else {
          window.postMessage({
            type: 'TC_FETCH_URL_RESULT',
            requestId: fetchRequestId,
            success: response.success,
            title: response.title,
            content: response.content,
            url: response.url,
            error: response.error
          }, postOrigin());
        }
      });
    } catch (err) {
      window.postMessage({
        type: 'TC_FETCH_URL_RESULT',
        requestId: fetchRequestId,
        success: false,
        error: chrome.i18n.getMessage('errorExtensionUnknown', [err.message || 'unknown'])
      }, postOrigin());
    }
  }

  if (event.data.type === 'TC_PROXY_FETCH') {
    var proxyId = event.data.requestId;
    var proxyPayload = {
      type: 'PROXY_FETCH',
      requestId: proxyId,
      documentToken: proxyDocumentToken || (proxyDocumentToken = crypto.randomUUID()),
      url: event.data.url,
      method: event.data.method || 'GET',
      headers: event.data.headers || {},
      body: event.data.body || null,
    };

    if (!isExtensionValid()) {
      window.postMessage({
        type: 'TC_PROXY_FETCH_RESULT',
        requestId: proxyId,
        success: false,
        error: chrome.i18n.getMessage('errorExtensionInvalidated')
      }, postOrigin());
      return;
    }

    try {
      chrome.runtime.sendMessage(proxyPayload, function (response) {
        var lastError = chrome.runtime.lastError;
        if (lastError) {
          window.postMessage({
            type: 'TC_PROXY_FETCH_RESULT',
            requestId: proxyId,
            success: false,
            error: lastError.message || chrome.i18n.getMessage('errorExtensionError')
          }, postOrigin());
        } else if (!response) {
          window.postMessage({
            type: 'TC_PROXY_FETCH_RESULT',
            requestId: proxyId,
            success: false,
            error: chrome.i18n.getMessage('errorNoResponse')
          }, postOrigin());
        } else {
          window.postMessage({
            type: 'TC_PROXY_FETCH_RESULT',
            requestId: proxyId,
            success: response.success,
            status: response.status,
            statusText: response.statusText,
            data: response.data,
            headers: response.headers,
            error: response.error
          }, postOrigin());
        }
      });
    } catch (err) {
      window.postMessage({
        type: 'TC_PROXY_FETCH_RESULT',
        requestId: proxyId,
        success: false,
        error: chrome.i18n.getMessage('errorExtensionUnknown', [err.message || 'unknown'])
      }, postOrigin());
    }
  }

  if (event.data.type === 'TC_PROXY_ABORT' && proxyDocumentToken) {
    chrome.runtime.sendMessage({ type: 'PROXY_ABORT', requestId: event.data.requestId, documentToken: proxyDocumentToken })
      .catch(function () { /* Local caller has already stopped waiting. */ });
  }

  if (event.data.type === 'TC_SET_PROXY_DOMAINS') {
    // Web app sends its configured integration domains so the proxy can enforce an allowlist
    if (!isExtensionValid()) return;
    var domains = Array.isArray(event.data.domains) ? event.data.domains : [];
    try {
      chrome.runtime.sendMessage({ type: 'SET_PROXY_DOMAINS', domains: domains });
    } catch { /* The extension can unload before this best-effort policy update. */ }
  }

  if (event.data.type === 'TC_LLM_ABORT') {
    var abortId = event.data.requestId;
    var abortPort = ports.get(abortId);
    if (abortPort) {
      abortPort.finish();
    }
  }

  if (event.data.type === 'TC_SEND_NOTIFICATION') {
    if (!isExtensionValid()) return;
    var notifPayload = event.data.payload || {};
    try {
      chrome.runtime.sendMessage({
        type: 'SEND_NOTIFICATION',
        title: notifPayload.title || 'CaddyAgent',
        message: notifPayload.message || '',
        severity: notifPayload.severity || 'warning',
      }).then(function (response) {
        window.postMessage({ type: 'TC_NOTIFICATION_RESULT', requestId: event.data.requestId,
          success: response?.success === true, accepted: response?.accepted === true,
          error: response?.error || null }, postOrigin());
      }).catch(function (error) {
        window.postMessage({ type: 'TC_NOTIFICATION_RESULT', requestId: event.data.requestId,
          success: false, error: error.message }, postOrigin());
      });
    } catch (e) {
      window.postMessage({ type: 'TC_NOTIFICATION_RESULT', requestId: event.data.requestId, success: false, error: e.message }, postOrigin());
    }
  }
});

// Handle messages from background script (works on both Chrome and Firefox)
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (sender.id !== chrome.runtime.id) return;
  if (!tcAppApproved) { sendResponse({ success: false, error: 'App not approved' }); return; }
  if (message.type === 'THREATCADDY_PING') {
    sendResponse({ pong: true });
    return;
  }
  if (message.type === 'GET_CLIP_IMPORT_TARGET') {
    if (!clipDocumentToken) clipDocumentToken = crypto.randomUUID();
    var probeId = crypto.randomUUID();
    var approvalRequest = tcApprovalRequest;
    var timer = setTimeout(function () {
      clipProbes.delete(probeId);
      sendResponse({ protocol: 2, ready: false, error: 'The app did not report a workspace' });
    }, 1000);
    clipProbes.set(probeId, function (ready) {
      clearTimeout(timer);
      clipProbes.delete(probeId);
      sendResponse({ protocol: 2, ready: ready.ready === true && tcAppApproved && approvalRequest === tcApprovalRequest,
        workspaceId: ready.workspaceId, workspaceLabel: ready.workspaceLabel, documentToken: clipDocumentToken });
    });
    window.postMessage({ type: 'TC_CLIP_IMPORT_PROBE', requestId: probeId, protocol: 2 }, postOrigin());
    return true;
  }
  if (message.type === 'INJECT_CLIPS_TO_PAGE') {
    if (message.envelope?.protocol !== 2 || !clipDocumentToken || message.documentToken !== clipDocumentToken) {
      sendResponse({ delivered: false, error: 'Prepare and confirm this app document before importing' }); return;
    }
    window.postMessage(message.envelope, postOrigin());
    sendResponse({ delivered: true, confirmed: false });
  }
});

} // end duplicate-injection guard
